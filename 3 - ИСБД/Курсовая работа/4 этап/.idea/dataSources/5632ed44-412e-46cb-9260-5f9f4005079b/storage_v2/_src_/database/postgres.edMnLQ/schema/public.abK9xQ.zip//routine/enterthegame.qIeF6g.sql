create procedure enterthegame(IN arg_login character varying, IN game_name character varying)
    language plpgsql
as
$$
BEGIN

    IF (SELECT library.id
        FROM library
        WHERE library.user_login = arg_login
          AND library.game_id IN (SELECT games.id FROM games WHERE games.name = game_name)) IS NOT NULL
    THEN
        UPDATE library
        SET last_run_date = current_timestamp
        WHERE library.user_login = arg_login
          AND library.game_id IN (SELECT games.id FROM games WHERE games.name = game_name);
    ELSE
        RAISE EXCEPTION 'Данный пользователь/игра не существует';
    END IF;
END
$$;

alter procedure enterthegame(varchar, varchar) owner to postgres;

