create procedure loginasuser(IN arg_login character varying)
    language plpgsql
as
$$
BEGIN

    IF (SELECT login FROM users WHERE users.login = arg_login) IS NOT NULL
    THEN
        UPDATE users
        SET last_login_date = current_date,
            status='В сети'
        WHERE users.login = arg_login;
    ELSE
        RAISE EXCEPTION 'Данный пользователь не зарегистрирован';
    END IF;
END
$$;

alter procedure loginasuser(varchar) owner to postgres;

