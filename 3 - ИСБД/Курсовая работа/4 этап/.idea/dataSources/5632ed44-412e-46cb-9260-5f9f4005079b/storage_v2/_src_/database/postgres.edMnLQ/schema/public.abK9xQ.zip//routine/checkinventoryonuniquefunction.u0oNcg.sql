create function checkinventoryonuniquefunction() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT(*)
        FROM inventory
        WHERE inventory.user_login = NEW.user_login
          AND inventory.item_id = NEW.item_id
        GROUP BY inventory.user_login, inventory.item_id) > 1
    THEN
        DELETE
        FROM inventory
        WHERE inventory.id = NEW.id;
    END IF;

    UPDATE inventory
    SET amount = (SELECT amount
                  FROM inventory
                  WHERE inventory.user_login = NEW.user_login
                    AND inventory.item_id = NEW.item_id) + 1
    WHERE item_id = NEW.item_id
      AND user_login = NEW.user_login;
    RETURN NEW;
END;
$$;

alter function checkinventoryonuniquefunction() owner to postgres;

