create function checklibraryonuniquefunction() returns trigger
    language plpgsql
as
$$
DECLARE
    стоимость_игры real;
BEGIN
    IF (SELECT COUNT(*)
        FROM library
        WHERE library.user_login = NEW.user_login
          AND library.game_id = NEW.game_id
        GROUP BY library.user_login, library.game_id) >= 1
    THEN
        RAISE EXCEPTION 'У вас уже приобретена эта игра!';
    ELSE
        стоимость_игры = (SELECT shop.price FROM shop WHERE shop.game_id = NEW.game_id);

        IF (SELECT wallets.balance
            FROM wallets
            WHERE wallets.id IN (SELECT users.wallet_id FROM users WHERE users.login = NEW.user_login)) < стоимость_игры
        THEN
            RAISE EXCEPTION 'У вас не хватает средств для покупки игры!';

        ELSE
            INSERT INTO transactions(user_login, transaction_type, sum, transaction_date)
            VALUES (NEW.user_login, 'Покупка игры', стоимость_игры, current_timestamp);

            UPDATE wallets
            SET balance=(SELECT wallets.balance
                         FROM wallets
                         WHERE wallets.id IN (SELECT users.wallet_id FROM users WHERE users.login = NEW.user_login)) -
                        стоимость_игры
            WHERE wallets.id IN (SELECT users.wallet_id FROM users WHERE users.login = NEW.user_login);
        END IF;


    END IF;
    RETURN NEW;
END
$$;

alter function checklibraryonuniquefunction() owner to postgres;

