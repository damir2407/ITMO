create function getgamenamebyid(id_arg integer) returns text
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT name FROM games WHERE id_arg = games.id);
END;
$$;

alter function getgamenamebyid(integer) owner to postgres;

