create function sellitemonmarket() returns trigger
    language plpgsql
as
$$
DECLARE
    количество_вещей integer := 0;
BEGIN
    IF (SELECT inventory.id
        FROM inventory
        WHERE inventory.item_id = NEW.item_id
          AND inventory.user_login = NEW.user_login) IS NULL
    THEN
        DELETE
        FROM market
        WHERE market.id = NEW.id;

        RAISE EXCEPTION 'Пользователь не может продать вещь, т.к не владеет ею';

    ELSE
        количество_вещей = (SELECT inventory.amount
                            FROM inventory
                            WHERE inventory.item_id = NEW.item_id
                              AND inventory.user_login = NEW.user_login);
        IF (количество_вещей > 1)
        THEN
            количество_вещей = количество_вещей - 1;

            UPDATE inventory
            SET amount=количество_вещей
            WHERE item_id = NEW.item_id
              AND user_login = NEW.user_login;
        ELSE
            DELETE
            FROM inventory
            WHERE inventory.item_id = NEW.item_id
              AND inventory.user_login = NEW.user_login;

        END IF;
    END IF;
    RETURN NEW;
END ;
$$;

alter function sellitemonmarket() owner to postgres;

