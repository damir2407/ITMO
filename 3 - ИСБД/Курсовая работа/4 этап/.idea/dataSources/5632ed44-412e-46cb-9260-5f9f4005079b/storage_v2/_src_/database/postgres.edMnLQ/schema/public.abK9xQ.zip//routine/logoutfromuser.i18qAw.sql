create procedure logoutfromuser(IN arg_login character varying)
    language plpgsql
as
$$
BEGIN

    IF (SELECT login FROM users WHERE users.login = arg_login) IS NOT NULL
    THEN
        UPDATE users
        SET status='Не в сети'
        WHERE users.login = arg_login;
    ELSE
        RAISE EXCEPTION 'Данный пользователь не зарегистрирован';
    END IF;
END ;
$$;

alter procedure logoutfromuser(varchar) owner to postgres;

