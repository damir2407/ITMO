create function checkshoponuniquefunction() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT(*)
        FROM shop
        WHERE shop.game_id = NEW.game_id
        GROUP BY shop.game_id) >= 1
    THEN
        RAISE EXCEPTION 'Запись об игре % уже существует в таблице Магазин', getGameNameById(NEW.game_id);
    END IF;
    RETURN NEW;
END
$$;

alter function checkshoponuniquefunction() owner to postgres;

