create function checkgameonuniquefunction() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT(*)
        FROM games
        WHERE games.name = NEW.name
        GROUP BY games.name) >= 1
    THEN
        RAISE EXCEPTION 'Данная игра уже опубликована!';
    END IF;
    RETURN NEW;
END
$$;

alter function checkgameonuniquefunction() owner to postgres;

