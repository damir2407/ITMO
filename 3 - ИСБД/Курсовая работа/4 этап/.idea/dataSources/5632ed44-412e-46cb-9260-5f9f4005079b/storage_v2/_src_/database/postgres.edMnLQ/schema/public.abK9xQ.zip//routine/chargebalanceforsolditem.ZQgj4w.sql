create procedure chargebalanceforsolditem(IN arg_login character varying, IN arg_balance double precision)
    language plpgsql
as
$$
DECLARE
    wallet_id_to_change integer;
BEGIN

    IF (SELECT users.login FROM users WHERE users.login = arg_login) IS NOT NULL
    THEN
        wallet_id_to_change = (SELECT users.wallet_id FROM users WHERE users.login = arg_login);
        UPDATE wallets
        SET balance= ((SELECT balance
                       FROM wallets
                       WHERE wallets.id = wallet_id_to_change) - arg_balance)
        WHERE wallets.id = wallet_id_to_change;

        INSERT INTO transactions(user_login, transaction_type, sum, transaction_date)
        VALUES (arg_login, 'Покупка вещи', arg_balance, current_timestamp);
    ELSE
        RAISE EXCEPTION 'Данный пользователь не зарегистрирован';
    END IF;
END;
$$;

alter procedure chargebalanceforsolditem(varchar, double precision) owner to postgres;

